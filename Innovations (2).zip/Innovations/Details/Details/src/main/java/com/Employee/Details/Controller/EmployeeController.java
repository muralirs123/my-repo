package com.Employee.Details.Controller;

import com.Employee.Details.Dto.EmployeeDto;
import com.Employee.Details.Service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/details")
public class EmployeeController {

    private EmployeeService employeeService;
    public EmployeeController(EmployeeService employeeService){
        this.employeeService=employeeService;
    }
    @PostMapping
    public ResponseEntity<Object> create(@Valid  @RequestBody EmployeeDto employeeDto, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            return new ResponseEntity<>(bindingResult.getFieldError().getDefaultMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(employeeService.create(employeeDto), HttpStatus.CREATED);
    }
    @GetMapping
    public List<EmployeeDto> getAll(){
        return employeeService.getAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDto> getById(@PathVariable (name="id")long id){
        return ResponseEntity.ok(employeeService.getById(id));
    }
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeDto> update(@RequestBody EmployeeDto employeeDto,@PathVariable (name="id")long id){
        EmployeeDto response=employeeService.update(employeeDto,id);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable(name="id")long id){
        employeeService.delete(id);
        return new ResponseEntity<>("Deleted Successfully",HttpStatus.OK);
    }

}
