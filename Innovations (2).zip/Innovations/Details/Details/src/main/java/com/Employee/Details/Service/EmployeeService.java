package com.Employee.Details.Service;

import com.Employee.Details.Dto.EmployeeDto;

import java.util.List;

public interface EmployeeService {
    EmployeeDto create(EmployeeDto employeeDto);

    List<EmployeeDto> getAll();

    EmployeeDto getById(long id);

    EmployeeDto update(EmployeeDto employeeDto, long id);

    void delete(long id);
}
