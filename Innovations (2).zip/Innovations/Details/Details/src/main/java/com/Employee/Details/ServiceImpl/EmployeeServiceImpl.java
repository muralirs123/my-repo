package com.Employee.Details.ServiceImpl;

import com.Employee.Details.Dto.EmployeeDto;
import com.Employee.Details.Entities.Employee;
import com.Employee.Details.Exception.ResourceNotFoundException;
import com.Employee.Details.Repository.EmployeeRepository;
import com.Employee.Details.Service.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private ModelMapper mapper;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, ModelMapper mapper) {
        this.employeeRepository = employeeRepository;
        this.mapper = mapper;
    }

    @Override
    public EmployeeDto create(EmployeeDto employeeDto) {
        Employee employee=mapToEntity(employeeDto);
        Employee newEmployee=employeeRepository.save(employee);
        EmployeeDto response=mapToDto(newEmployee);
        return response;
    }

    private EmployeeDto mapToDto(Employee newEmployee) {
        EmployeeDto employeeDto=mapper.map(newEmployee,EmployeeDto.class);
        return employeeDto;
    }

    private Employee mapToEntity(EmployeeDto employeeDto) {
        Employee employee=mapper.map(employeeDto,Employee.class);
        return employee;
    }

    @Override
    public List<EmployeeDto> getAll() {
        List<Employee> employee=employeeRepository.findAll();

        return employee.stream().map(employee1 -> mapToDto(employee1)).collect(Collectors.toList());
    }

    @Override
    public EmployeeDto getById(long id) {
        Employee employee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(
                "employee","id",id
        ));
        Employee response=employeeRepository.save(employee);
        return mapToDto(response);
    }

    @Override
    public EmployeeDto update(EmployeeDto employeeDto, long id) {
        Employee employee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(
                "employee","id",id
        ));
        mapper.map(employeeDto,employee);
        Employee newEmp=employeeRepository.save(employee);
        return mapper.map(newEmp,EmployeeDto.class);
    }

    @Override
    public void delete(long id) {
        Employee employee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(
                "employee","id",id
        ));
        employeeRepository.delete(employee);

    }
}
