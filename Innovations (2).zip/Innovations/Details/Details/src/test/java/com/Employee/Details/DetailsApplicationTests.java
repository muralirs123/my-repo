package com.Employee.Details;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
